//// SubBookDTO.java
//package com.example.cuseCafeConnect.models;
//
//import java.util.Date;
//
//public class SubBookDTO {
//    private int subID;
//    private int subTypeID;
//    private Date dropDate;
//    private int dropUser;
//    private int pickUpUser;
//    private int acceptSub;
//    private int cafeID;
//    public int getSubID() {
//		return subID;
//	}
//	public void setSubID(int subID) {
//		this.subID = subID;
//	}
//	public int getSubTypeID() {
//		return subTypeID;
//	}
//	public void setSubTypeID(int subTypeID) {
//		this.subTypeID = subTypeID;
//	}
//	public Date getDropDate() {
//		return dropDate;
//	}
//	public void setDropDate(Date dropDate) {
//		this.dropDate = dropDate;
//	}
//	public int getDropUser() {
//		return dropUser;
//	}
//	public void setDropUser(int dropUser) {
//		this.dropUser = dropUser;
//	}
//	public int getPickUpUser() {
//		return pickUpUser;
//	}
//	public void setPickUpUser(int pickUpUser) {
//		this.pickUpUser = pickUpUser;
//	}
//	public int getAcceptSub() {
//		return acceptSub;
//	}
//	public void setAcceptSub(int acceptSub) {
//		this.acceptSub = acceptSub;
//	}
//	public int getCafeID() {
//		return cafeID;
//	}
//	public void setCafeID(int cafeID) {
//		this.cafeID = cafeID;
//	}
//	public int getScheduleID() {
//		return scheduleID;
//	}
//	public void setScheduleID(int scheduleID) {
//		this.scheduleID = scheduleID;
//	}
//	public String getComments() {
//		return comments;
//	}
//	public void setComments(String comments) {
//		this.comments = comments;
//	}
//	private int scheduleID;
//    private String comments;
//
//    // Getters and setters
//}
