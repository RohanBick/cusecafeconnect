//// ScheduleWithTimeSlotDTO.java
//package com.example.cuseCafeConnect.models;
//
//public class ScheduleWithTimeSlotDTO {
//    private int scheduleID;
//    private int timeSlotID;
//    private int userID;
//    private int cafeID;
//    private int isAccepted;
//    private String requestComments;
//    private String timeSlot;
//    private String timeSlotDay;
//    
//    
//    
//	public int getScheduleID() {
//		return scheduleID;
//	}
//	public void setScheduleID(int scheduleID) {
//		this.scheduleID = scheduleID;
//	}
//	public int getTimeSlotID() {
//		return timeSlotID;
//	}
//	public void setTimeSlotID(int timeSlotID) {
//		this.timeSlotID = timeSlotID;
//	}
//	public int getUserID() {
//		return userID;
//	}
//	public void setUserID(int userID) {
//		this.userID = userID;
//	}
//	public int getCafeID() {
//		return cafeID;
//	}
//	public void setCafeID(int cafeID) {
//		this.cafeID = cafeID;
//	}
//	public int getIsAccepted() {
//		return isAccepted;
//	}
//	public void setIsAccepted(int isAccepted) {
//		this.isAccepted = isAccepted;
//	}
//	public String getRequestComments() {
//		return requestComments;
//	}
//	public void setRequestComments(String requestComments) {
//		this.requestComments = requestComments;
//	}
//	public String getTimeSlot() {
//		return timeSlot;
//	}
//	public void setTimeSlot(String timeSlot) {
//		this.timeSlot = timeSlot;
//	}
//	public String getTimeSlotDay() {
//		return timeSlotDay;
//	}
//	public void setTimeSlotDay(String timeSlotDay) {
//		this.timeSlotDay = timeSlotDay;
//	}
//
//    // Getters and setters
//    
//}
