package com.example.cuseCafeConnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuseCafeConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CuseCafeConnectApplication.class, args);
	}

}
