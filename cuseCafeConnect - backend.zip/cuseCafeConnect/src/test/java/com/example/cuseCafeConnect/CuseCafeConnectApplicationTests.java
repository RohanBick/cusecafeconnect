package com.example.cuseCafeConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CuseCafeConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
