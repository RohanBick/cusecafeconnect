package com.example.cuse_cafe_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
